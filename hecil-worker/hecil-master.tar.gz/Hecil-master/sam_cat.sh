#!/bin/sh

grep -v "^@PG" $1

for i in $(seq 1 $(( $# - 1 )))
do
	cat Out.$i.sam | grep -v "^@"
done

